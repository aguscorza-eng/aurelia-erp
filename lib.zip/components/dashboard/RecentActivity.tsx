import {
  Package,
  ShoppingCart,
  UserPlus,
  Factory,
} from "lucide-react";

const activity = [
  {
    icon: ShoppingCart,
    title: "Venta realizada",
    subtitle: "Pedido #2481 - $18.500",
  },
  {
    icon: Factory,
    title: "Producción finalizada",
    subtitle: "20 Velas Lavanda",
  },
  {
    icon: UserPlus,
    title: "Nuevo cliente",
    subtitle: "María Fernández",
  },
  {
    icon: Package,
    title: "Ingreso de insumos",
    subtitle: "Cera de soja",
  },
];

export default function RecentActivity() {
  return (
    <div className="bg-white rounded-3xl border border-stone-200 p-6 h-full">
      <h2 className="text-xl font-semibold mb-6">
        Actividad reciente
      </h2>

      <div className="space-y-5">
        {activity.map((item) => {
          const Icon = item.icon;

          return (
            <div
              key={item.title}
              className="flex items-center gap-4"
            >
              <div className="w-11 h-11 rounded-xl bg-stone-100 flex items-center justify-center">
                <Icon
                  size={20}
                  className="text-[#B08D57]"
                />
              </div>

              <div>
                <p className="font-medium">
                  {item.title}
                </p>

                <p className="text-sm text-stone-500">
                  {item.subtitle}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}