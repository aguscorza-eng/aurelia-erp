"use client";

import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
} from "recharts";

const data = [
  { day: "1", sales: 120 },
  { day: "5", sales: 240 },
  { day: "10", sales: 180 },
  { day: "15", sales: 320 },
  { day: "20", sales: 290 },
  { day: "25", sales: 430 },
  { day: "30", sales: 520 },
];

export default function SalesChart() {
  return (
    <div className="bg-white rounded-3xl border border-stone-200 p-8 h-[340px]">

      <div className="flex items-start justify-between mb-8">

        <div>
          <p className="text-sm text-stone-500">
            Ventas
          </p>

          <h2 className="text-3xl font-semibold mt-1">
            $1.245.800
          </h2>

          <p className="text-green-600 text-sm mt-2">
            ▲ 18% respecto al mes anterior
          </p>
        </div>

      </div>

      <ResponsiveContainer width="100%" height={220}>
        <AreaChart data={data}>

          <defs>

            <linearGradient id="sales" x1="0" y1="0" x2="0" y2="1">

              <stop offset="0%" stopColor="#B08D57" stopOpacity={0.35} />

              <stop offset="100%" stopColor="#B08D57" stopOpacity={0} />

            </linearGradient>

          </defs>

          <CartesianGrid
            stroke="#f3f4f6"
            vertical={false}
          />

          <XAxis
            dataKey="day"
            tickLine={false}
            axisLine={false}
          />

          <Tooltip />

          <Area
            type="monotone"
            dataKey="sales"
            stroke="#B08D57"
            strokeWidth={3}
            fill="url(#sales)"
          />

        </AreaChart>
      </ResponsiveContainer>

    </div>
  );
}