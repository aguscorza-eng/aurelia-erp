"use client";

import { useEffect, useState } from "react";
import { TrendingUp } from "lucide-react";

const products = [
  {
    rank: "#1",
    name: "Difusor Bamboo",
    category: "Difusores",
    price: "$7.900",
    margin: "42%",
    sales: 324,
  },
  {
    rank: "#2",
    name: "Vela Lavanda",
    category: "Velas",
    price: "$6.500",
    margin: "38%",
    sales: 281,
  },
  {
    rank: "#3",
    name: "Gift Box Premium",
    category: "Gift Boxes",
    price: "$12.500",
    margin: "35%",
    sales: 194,
  },
  {
    rank: "#4",
    name: "Hornito Nórdico",
    category: "Hornitos",
    price: "$9.900",
    margin: "31%",
    sales: 132,
  },
];

export default function TopProductsCarousel() {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % products.length);
    }, 4000);

    return () => clearInterval(timer);
  }, []);

  const product = products[current];

  return (
    <div className="bg-white border border-stone-200 rounded-3xl p-8 h-full flex flex-col">

      {/* Header */}

      <div className="flex items-center justify-between">

        <div>

          <p className="text-sm text-stone-500">
            Ranking
          </p>

          <h2 className="text-3xl font-semibold mt-1">
            Producto líder
          </h2>

        </div>

        <div className="rounded-full bg-[#F7F2EB] px-4 py-2">

          <span className="font-semibold text-[#B08D57]">
            {product.rank}
          </span>

        </div>

      </div>

      {/* Nombre */}

      <div className="mt-10">

        <h3 className="text-3xl font-semibold leading-tight">

          {product.name}

        </h3>

        <p className="text-stone-500 mt-2">

          {product.category}

        </p>

      </div>

      {/* Datos */}

      <div className="mt-10 space-y-5">

        <div className="flex justify-between">

          <span className="text-stone-500">

            Ventas

          </span>

          <strong>

            {product.sales}

          </strong>

        </div>

        <div className="flex justify-between">

          <span className="text-stone-500">

            Precio

          </span>

          <strong>

            {product.price}

          </strong>

        </div>

        <div className="flex justify-between items-center">

          <span className="text-stone-500">

            Margen

          </span>

          <div className="flex items-center gap-2 text-emerald-600 font-semibold">

            <TrendingUp size={18} />

            {product.margin}

          </div>

        </div>

      </div>

      {/* Separador */}

      <div className="border-t border-stone-200 my-8" />

      {/* Indicadores */}

      <div className="flex justify-center gap-2 mt-auto">

        {products.map((_, index) => (

          <button
            key={index}
            onClick={() => setCurrent(index)}
            className={`transition-all duration-300 rounded-full ${
              current === index
                ? "w-8 h-2 bg-[#B08D57]"
                : "w-2 h-2 bg-stone-300"
            }`}
          />

        ))}

      </div>

    </div>
  );
}