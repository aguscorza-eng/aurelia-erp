import { AlertTriangle } from "lucide-react";

const alerts = [
  "Stock bajo de Cera de Soja",
  "Frascos transparentes por debajo del mínimo",
  "14 pedidos pendientes",
  "2 órdenes de producción atrasadas",
];

export default function Alerts() {
  return (
    <div className="bg-white rounded-3xl border border-stone-200 p-6 h-full">
      <h2 className="text-xl font-semibold mb-6">
        Alertas
      </h2>

      <div className="space-y-4">
        {alerts.map((alert) => (
          <div
            key={alert}
            className="flex items-start gap-3"
          >
            <AlertTriangle
              size={18}
              className="text-amber-500 mt-1"
            />

            <p className="text-sm leading-6">
              {alert}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}