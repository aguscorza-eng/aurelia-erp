"use client";

import { useEffect, useMemo, useState } from "react";
import {
  MoreHorizontal,
  Pencil,
  Trash2,
} from "lucide-react";

import ProductFilters from "./ProductFilters";

type Product = {
  id: string;
  name: string;
  sku: string;
  stock: number;
  minimumStock: number;
  cost: number;
  price: number;
  category: {
    name: string;
  };
};

interface Props {
  onEdit: (id: string) => void;
}

export default function ProductsTable({
  onEdit,
}: Props) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    loadProducts();
  }, []);

  async function loadProducts() {
    try {
      const res = await fetch("/api/products");
      const json = await res.json();

      setProducts(json.data ?? []);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  }

  async function deleteProduct(id: string, name: string) {
    if (!confirm(`¿Eliminar "${name}"?`)) return;

    try {
      const res = await fetch(`/api/products/${id}`, {
        method: "DELETE",
      });

      if (!res.ok) {
        alert("No se pudo eliminar.");
        return;
      }

      setProducts((prev) =>
        prev.filter((p) => p.id !== id)
      );

    } catch (error) {
      console.error(error);
    }
  }

  const filteredProducts = useMemo(() => {
    const value = search.toLowerCase();

    return products.filter((product) =>
      product.name.toLowerCase().includes(value) ||
      product.sku.toLowerCase().includes(value) ||
      product.category?.name.toLowerCase().includes(value)
    );
  }, [products, search]);

  if (loading) {
    return (
      <div className="bg-white rounded-3xl border p-10 text-center">
        Cargando productos...
      </div>
    );
  }

  return (
    <div className="space-y-5">

      <ProductFilters
        search={search}
        setSearch={setSearch}
      />

      <div className="bg-white rounded-3xl border border-stone-200 overflow-hidden">

        <table className="w-full">

          <thead className="bg-stone-50">

            <tr className="text-left text-sm text-stone-500">

              <th className="w-20 px-6 py-4">
                Imagen
              </th>

              <th>Producto</th>
              <th>SKU</th>
              <th>Stock</th>
              <th>Costo</th>
              <th>Precio</th>
              <th>Categoría</th>
              <th>Estado</th>
              <th className="w-32"></th>

            </tr>

          </thead>

          <tbody>

            {filteredProducts.map((product) => {

              const estado =
                product.stock === 0
                  ? "Sin stock"
                  : product.stock <= product.minimumStock
                  ? "Stock bajo"
                  : "En stock";

              const color =
                product.stock === 0
                  ? "bg-red-100 text-red-700"
                  : product.stock <= product.minimumStock
                  ? "bg-yellow-100 text-yellow-700"
                  : "bg-emerald-100 text-emerald-700";

              return (
                <tr
                  key={product.id}
                  className="border-t hover:bg-stone-50 transition"
                >

                  <td className="px-6 py-4">
                    <div className="w-12 h-12 rounded-xl bg-stone-100 border flex items-center justify-center text-xs text-stone-400">
                      IMG
                    </div>
                  </td>

                  <td className="font-semibold">
                    {product.name}
                  </td>

                  <td>{product.sku}</td>

                  <td>{product.stock}</td>

                  <td>
                    $
                    {Number(product.cost).toLocaleString("es-AR")}
                  </td>

                  <td className="font-semibold">
                    $
                    {Number(product.price).toLocaleString("es-AR")}
                  </td>

                  <td>
                    {product.category?.name}
                  </td>

                  <td>

                    <span
                      className={`px-3 py-1 rounded-full text-sm ${color}`}
                    >
                      {estado}
                    </span>

                  </td>

                  <td>

                    <div className="flex justify-end gap-2 pr-5">

                      <button
                        onClick={() => onEdit(product.id)}
                        className="h-9 w-9 rounded-lg hover:bg-stone-100 flex items-center justify-center"
                      >
                        <Pencil size={16} />
                      </button>

                      <button
                        onClick={() =>
                          deleteProduct(
                            product.id,
                            product.name
                          )
                        }
                        className="h-9 w-9 rounded-lg hover:bg-red-50 hover:text-red-600 flex items-center justify-center"
                      >
                        <Trash2 size={16} />
                      </button>

                      <button
                        className="h-9 w-9 rounded-lg hover:bg-stone-100 flex items-center justify-center"
                      >
                        <MoreHorizontal size={16} />
                      </button>

                    </div>

                  </td>

                </tr>
              );

            })}

          </tbody>

        </table>

      </div>

    </div>
  );
}