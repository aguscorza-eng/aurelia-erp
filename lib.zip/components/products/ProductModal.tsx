"use client";

import { useState } from "react";

interface Props {
  open: boolean;
  onClose: () => void;
}

export default function ProductModal({
  open,
  onClose,
}: Props) {
  const [name, setName] = useState("");
  const [sku, setSku] = useState("");
  const [cost, setCost] = useState("");
  const [price, setPrice] = useState("");
  const [stock, setStock] = useState("");
  const [minimumStock, setMinimumStock] = useState("");
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(false);

  if (!open) return null;

  async function saveProduct() {
    if (!name.trim()) {
      alert("Ingresá el nombre del producto");
      return;
    }

    if (!sku.trim()) {
      alert("Ingresá el SKU");
      return;
    }

    setLoading(true);

    try {
      const res = await fetch("/api/products", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name,
          sku,
          description,
          cost,
          price,
          stock,
          minimumStock,
        }),
      });

      if (!res.ok) {
        const error = await res.json();
        alert(error.error ?? "No se pudo guardar");
        return;
      }

      // Limpiar formulario
      setName("");
      setSku("");
      setCost("");
      setPrice("");
      setStock("");
      setMinimumStock("");
      setDescription("");

      // Cerrar modal
      onClose();

      // Actualizar tabla
      window.location.reload();

    } catch (error) {
      console.error(error);
      alert("Error de conexión");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">

      <div className="bg-white rounded-3xl w-[700px] p-8">

        <h2 className="text-3xl font-bold mb-8">
          Nuevo Producto
        </h2>

        <div className="grid grid-cols-2 gap-5">

          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Nombre"
            className="border rounded-xl h-12 px-4"
          />

          <input
            value={sku}
            onChange={(e) => setSku(e.target.value)}
            placeholder="SKU"
            className="border rounded-xl h-12 px-4"
          />

          <input
            value={cost}
            onChange={(e) => setCost(e.target.value)}
            placeholder="Costo"
            type="number"
            className="border rounded-xl h-12 px-4"
          />

          <input
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            placeholder="Precio"
            type="number"
            className="border rounded-xl h-12 px-4"
          />

          <input
            value={stock}
            onChange={(e) => setStock(e.target.value)}
            placeholder="Stock"
            type="number"
            className="border rounded-xl h-12 px-4"
          />

          <input
            value={minimumStock}
            onChange={(e) => setMinimumStock(e.target.value)}
            placeholder="Stock mínimo"
            type="number"
            className="border rounded-xl h-12 px-4"
          />

        </div>

        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Descripción"
          className="border rounded-xl w-full h-32 mt-5 p-4 resize-none"
        />

        <div className="flex justify-end gap-3 mt-8">

          <button
            onClick={onClose}
            disabled={loading}
            className="h-11 px-6 rounded-xl border"
          >
            Cancelar
          </button>

          <button
            onClick={saveProduct}
            disabled={loading}
            className="h-11 px-6 rounded-xl bg-stone-900 text-white"
          >
            {loading ? "Guardando..." : "Guardar producto"}
          </button>

        </div>

      </div>

    </div>
  );
}